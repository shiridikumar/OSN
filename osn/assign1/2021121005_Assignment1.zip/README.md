# **OSN Assignment1**
## **Intro to System calls**

***
>Contents and Assignment Structure

- q1.c
- q2.c
- q3.c 
- /Assignment (Destination directory which will be created for output files after executing the code)

>Assumptions Made

- Destination Assignment Directory is assumed to be created in the curent working directory

- Same file is given as input for all q1.c ,q2.c and q3.c

- The output filename for q1.c is assumed to be 1_filename.txt

- The output filename for q2.c is assumed to be 2_filename.txt

- Libraries used :
    - stdio.h for sprintf
    - stdlib.h for malloc
    - sys/stat.h for stat function
    - fcntl.h for file read and write operations
    - string.h for string manupulations
























